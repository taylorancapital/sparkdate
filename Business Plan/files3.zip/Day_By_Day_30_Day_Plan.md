# Day-by-Day Execution Plan — First 30 Days

**Premise:** The 12-month GTM plan is great strategy. This is great tactics. Same destination, finer grain.

**Time commitment assumed:** ~30-40 hrs/week solo founder. Adjust if you're full-time on this.

---

## WEEK 0 — Setup (Before Day 1)

Do these the day you read this. None take more than an hour.

- [ ] Buy `sparkdate.com` (Cloudflare Registrar, ~$10)
- [ ] Sign up: Vercel (free), Formspree (free), ConvertKit (free tier)
- [ ] Deploy landing page to Vercel — get live URL
- [ ] Wire Formspree into landing page form, test it
- [ ] Reserve handles: Instagram `@sparkdate`, TikTok `@sparkdate`, X `@sparkdateapp` (if .com is gone, use `.co`)
- [ ] Sign IP Assignment Agreement with Ancapital Group LLC (filed in your records)
- [ ] Set up shared bank account or business account for Ancapital (if not done)
- [ ] Create a Notion or Airtable workspace with three boards: **Venues**, **Communities**, **Founding Members**

---

## WEEK 1 — Foundations (Days 1-7)

### Day 1 (Monday)
- [ ] Email yourself, your partner, and 5 close friends the landing page URL — get first 6 waitlist signups
- [ ] Post Manifesto carousel (Post 1 from Recruitment Kit) to your personal Instagram
- [ ] Add link to Instagram bio
- [ ] Identify 10 Philly community organizers (use list in Recruitment Kit, add 5 of your own)
- [ ] Research each organizer's name, recent post, and best contact channel

### Day 2
- [ ] Send Script A or B (cold DM) to all 10 community organizers
- [ ] Send venue outreach email Template 1 to first 5 Rittenhouse venues (personalize each — owner name, specific compliment)
- [ ] Take a 30-min coffee meeting with one trusted person who knows Philly nightlife (anyone — bartender friend, hospitality alum, etc.). Ask: *"Who's the GM I should know at [venue]?"*

### Day 3
- [ ] Send venue email Template 1 to next 5 Rittenhouse venues (10 total sent this week)
- [ ] Reply to any organizer/venue responses immediately (response speed = perceived seriousness)
- [ ] Draft event run-of-show document (90-min event format, attendee flow, host script). 1 page.

### Day 4
- [ ] Post stat drop (Post 2) to Instagram
- [ ] Take any meetings booked from days 2-3
- [ ] Identify 3 likely "first event" venues from responders. Soft-confirm a date.

### Day 5
- [ ] Reach out to 5 friends who are good connectors in Philly. Tell them what you're doing. Ask if they'd refer 2-3 women they know who'd be into it.
- [ ] Begin assembling the founding member application screening checklist (use criteria from Recruitment Kit)

### Day 6 (Saturday)
- [ ] Walk Rittenhouse and Old City. Visit 5 of your target venues in person. Get a drink. Note: vibe, light level, sound level, table arrangement, who comes in on what night.
- [ ] DM the 5 best community organizers from Day 1 who haven't replied: a casual nudge

### Day 7 (Sunday)
- [ ] Review the week. Update Notion. Send yourself one honest text: *"Did I do enough this week?"*
- [ ] Plan Week 2

**Week 1 success metrics:**
- Landing page live: ✓
- 10 venue emails sent
- 10 organizer DMs sent
- 3 venue meetings booked or confirmed
- 15-25 waitlist signups
- 1 first event date soft-confirmed

---

## WEEK 2 — Lock the First Event (Days 8-14)

### Day 8 (Monday)
- [ ] Follow up (Template 3) on any non-responding venues from Week 1
- [ ] Send venue Template 1 to 5 Old City venues
- [ ] Take any meetings booked

### Day 9
- [ ] **Lock down First Event venue** — send Template 4 (confirmation email)
- [ ] Set First Event date in calendar — should be **Day 22-26 of Week 4**, ~14 days out
- [ ] Create Eventbrite or Lu.ma event page (private, link-only access)

### Day 10
- [ ] Founding members open: send the founding-member application link to:
  - All organizers who've replied positively
  - Your 5 connector friends
  - Anyone who's signed up to the waitlist already
- [ ] Post founder note (Post 3) to Instagram
- [ ] Begin reviewing applications as they come in. Approve or soft-decline within 24 hrs.

### Day 11
- [ ] Hand-pick + DM 15 ideal prospects directly (Recruitment Kit "Direct DM" script). Mix: 60% women, 40% men.
- [ ] Schedule first attendee briefing call — 15 min Zoom on Day 18 for any approved founding members. Optional but builds anticipation.

### Day 12
- [ ] Send venue briefing one-pager to First Event venue (3 days from event = Day 19, but do it now while it's top of mind)
- [ ] Confirm event insurance — Hiscox, Embroker, or similar. ~$300-500 for one-off event coverage. Name venue as additional insured.

### Day 13
- [ ] Continue venue outreach — Old City + Fishtown wave (5 more emails)
- [ ] Follow up with the 15 hand-picked prospects who haven't replied

### Day 14 (Sunday)
- [ ] Audit founding member roster. Aim: 35-50 approved, 50%+ female, ages roughly distributed across 25-34
- [ ] If gender mix is off (under 45% female), pause approving men until you fill in women
- [ ] Plan Week 3

**Week 2 success metrics:**
- First Event venue confirmed with date
- 30+ founding member applications received
- 25+ founding members approved
- 50%+ female ratio
- 40-60 waitlist signups total

---

## WEEK 3 — Build Anticipation (Days 15-21)

### Day 15 (Monday)
- [ ] Public First Event announcement: post on Instagram with date + venue (general date, not exact address yet)
- [ ] Send First Event RSVP link **to founding members only** — they get 48-hour priority window before public release
- [ ] Begin filling 25-35 attendee slots. Cap at 35 for first event (small enough to fix problems).

### Day 16
- [ ] Post Reel 1 ("Why Tinder is Over") to TikTok and Instagram Reels
- [ ] Reply to every comment and DM within 4 hours. Build the brand voice in real-time.

### Day 17
- [ ] Open public RSVPs (after founding members have had 48 hrs)
- [ ] Send waitlist email blast: *"First event is this Friday. Founding members already in. 8 public spots remaining. Link below."*
- [ ] Track signup velocity — if it's slow, push harder on social. If fast, celebrate.

### Day 18
- [ ] Host the optional 15-min Zoom for founding members. Tell them: vibe of the event, what to expect, how to introduce themselves. Build anticipation, not anxiety.
- [ ] Send Day-Of operational doc to your Day-Of helpers (likely just you + 1 host friend)

### Day 19
- [ ] Send venue final briefing one-pager (Day-Of Quick Reference)
- [ ] Confirm with venue: bar staffing, reserved area, music, AV needs
- [ ] Post founding member spotlight: with permission, share a quote from one founding member explaining why they joined

### Day 20
- [ ] **Final RSVP confirmation push** — anyone with a ticket but who hasn't confirmed gets a friendly text: *"Excited to see you at [venue] tomorrow night at 7! Reply YES to confirm your spot."*
- [ ] Last-minute fill: if any attendees no-show'd in confirmations, pull from a 5-person standby list

### Day 21 (Sunday — Day before First Event if running Mon, otherwise rest day)
- [ ] If event is Day 22 (Mon): rest, prep mentally, lay out clothes, recharge phone
- [ ] If event is Day 26 (Fri): Continue public RSVP push, plan Week 4

**Week 3 success metrics:**
- Event page is live and selling
- 25-35 confirmed RSVPs (paid)
- 50%+ female confirmed
- ~$1K in ticket revenue
- Reel got 2K+ views

---

## WEEK 4 — Run, Reflect, Repeat (Days 22-30)

### Event Day (Day 22-26 depending on which night)
- [ ] Arrive 45 min early
- [ ] Set up check-in table
- [ ] Brief venue staff (use one-pager)
- [ ] Check first attendees in personally — set the tone
- [ ] Run the event (your job: facilitate intro, then disappear into the crowd, observe)
- [ ] Don't drink more than 1 drink yourself. You're working.
- [ ] At end: thank everyone, hand-write 3 thank-yous to standout attendees
- [ ] Tip venue staff $20 each in cash from your pocket (not from venue)

### Day After Event (Day 23/27)
- [ ] Send "thank you" email to all attendees within 12 hours. Include: 3 photos (with consent), link to RSVP next event, request honest feedback
- [ ] Send specific text to founding members: *"What did you actually think? Be honest. What sucked?"*
- [ ] Send venue follow-up email: receipts, thank-you, F&B recap, ask about a recurring slot
- [ ] Take 2 hours to write a brutal post-mortem document. What worked. What didn't. What you'd change.

### Day 24/28
- [ ] Post event recap on Instagram (with attendee permission). Show real photos, not stock energy.
- [ ] Send recap to waitlist: *"Last night happened. 32 people. Here's what it looked like. Next event: [date]."*
- [ ] Begin Event #2 planning. Same venue or new? Adjust based on Event #1 lessons.

### Day 25-29
- [ ] Confirm Event #2 venue (could be same, could be new)
- [ ] Open RSVPs for Event #2 — founding members first
- [ ] Continue Old City + Fishtown venue outreach. Goal: 3 confirmed venue partners by Day 30.
- [ ] DM 10 more community organizers — now you have proof to show

### Day 30 (Sunday — Reflection)
- [ ] Write a Day 30 honest assessment:
  - Founding members: target 50, actual ___
  - Venue partners: target 3 confirmed, actual ___
  - Events run: target 1, actual ___
  - Waitlist signups: target 100, actual ___
  - Female %: target 50%, actual ___
  - Repeat attendance interest: target 60%+, actual ___
- [ ] Identify the **one thing** that's furthest behind plan. That's Week 5's #1 priority.
- [ ] Reward yourself for Day 30. Whatever that means for you. You earned it.

---

## END OF MONTH 1 — DECISION POINT

You'll know by Day 30 whether the model has signal. Real signal looks like:

- ✓ Event #1 sold out or nearly sold out
- ✓ 60%+ of attendees said they'd come to another one
- ✓ Venue is willing to do another event
- ✓ Founding members are actively referring friends
- ✓ Female % stayed above 45%

If 4 of 5 above are true, **scale up Week 5+**: more events, second venue, paid ad test.

If 2 or fewer are true, **don't scale yet**. Run Event #2 with the same playbook, fix what's broken, decide at Day 60.

If 0-1 are true, the model isn't working in Philadelphia. Time to talk hard truths — pivot the format, change the city, or stop. Better to know at Month 1 than Month 6.

---

## DAILY HABITS (Every Single Day)

- **AM (15 min):** Reply to every DM, every email, every comment from yesterday. Speed wins.
- **Once a day:** Update Notion boards (Venues, Communities, Founding Members)
- **Once a day:** Post or engage on at least one social channel
- **Once a week:** 1 venue visit in person (drink, observe, build relationships)
- **Sunday night:** Plan the upcoming week. 30 minutes. Non-negotiable.

---

## RED FLAGS — STOP AND RETHINK IF:

- 🚩 You're at Day 14 with no confirmed venue → outreach is broken, rewrite the email
- 🚩 You're at Day 20 with under 15 RSVPs → demand is weak, audit your funnel
- 🚩 You're at Day 25 with under 30% female ratio → kill non-female channels, double down on women-first communities
- 🚩 Founding members aren't applying after 14 days → your offer isn't compelling, rework the perks
- 🚩 You're personally exhausted by Day 21 → you're doing too much yourself, recruit Co-Host #1 sooner

---

## WHAT NOT TO DO (Common Founder Traps)

- ❌ **Don't run paid ads in Month 1.** You don't yet know what message converts. Burning ad spend before message-market fit is wasted money.
- ❌ **Don't host more than 1 event in Month 1.** Quality over quantity. One legendary event > three mediocre ones.
- ❌ **Don't accept just any venue.** A wrong venue dilutes the brand permanently. Wait for the right one.
- ❌ **Don't skip the post-mortem.** Most founders skip the reflection step. The lessons are worth more than the events themselves.
- ❌ **Don't talk to investors yet.** You don't have proof. Wait until Event #3 or Month 2.
- ❌ **Don't build the app yet.** A spreadsheet + Eventbrite is enough for the first 4-6 events. Build code only when manual breaks.

---

## ONE LINE THAT MATTERS

> The first event isn't a product launch.
> It's a hypothesis test.
> You'll know more in 90 minutes than you'd learn in 90 days of strategizing.

Run the test. Fast. The plan is in your hands. Go.
